const readline = require('readline').createInterface(
    {
        input: process.stdin,
        output: process.stdout,
    }
)
const temp = 62
const isSummer = new Boolean(true)

function squirrelPlay() {
    if (temp > 60 < 90 && isSummer == false); {
        console.log("Squirrels are playing")
    } if (temp > 60 < 100 && isSummer == true); {
        console.log("Squirrels are playing")
    } else { // Don't know what's wrong with this
        console.log("Squirrels are not playing")
    }
}
squirrelPlay()

// Nife's Notes
    // Check your if statements, when you have multiple,
    // you put an else infront of the second, third etc... if's to chain them together
    // otherwise they will each run independently
    // Also, no for the if statement, just on one line statements in blocks
    // ex: 
    // if( ) {

    // } else if() {

    // } else {

    // }