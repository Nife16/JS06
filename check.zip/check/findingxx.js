const readline = require('readline').createInterface(
    {
        input: process.stdin,
        output: process.stdout,
    }
)
const one = "abcxx"

function findXx() {
    if (one.includes("xx")){
        console.log("True")
    } else {
        console.log("False")
    }
    readline.close()
}
findXx()

// Try to make this work by counting the number of xx within a string
// If the string was abcxxx, it should say there are 2 occurences of xx
// in the string. You will need to loop through the string, like an array