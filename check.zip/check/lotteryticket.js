const readline = require('readline').createInterface(
    {
        input: process.stdin,
        output: process.stdout,
    }
)
const firstNumber = 2
const secondNumber = 2
const thirdNumber = 2

function lotteryTicket() {
    if (firstNumber == secondNumber == thirdNumber == firstNumber) {
        console.log("The result is 20")
    } if (firstNumber == secondNumber || firstNumber == thirdNumber || secondNumber == thirdNumber) {
        console.log("The result is 10")
    } if (firstNumber !== secondNumber !== thirdNumber !== firstNumber) {
        console.log("The result is 0")
    }
    readline.close()
}
lotteryTicket()
// Don't know where to go from here

// Nife's Notes:
    // Check how you are writing your conditions,
    // they should be separated to look at one boolean condition at a time
    // Right now the first if statement is not working correctly.
    // Try to seperate them like: if( (firstNumber == secondNumber) && (firstNumber == thirdNumber) ) { }
    // Also, you are missing something in your if statesments, when you want to chain multiple if's together
    // you need to use else to make them a chain, right now it will check each one
    // no matter what. It would be better if it checked them in a chain so when one is true, it wont go to the next
    