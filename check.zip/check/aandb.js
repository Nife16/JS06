const readline = require('readline').createInterface(
    {
        input: process.stdin,
        output: process.stdout,
    }
)
function sumLimit() {
    readline.question("What is the first number: ", function (firstNumber){
        readline.question("What is the second number: ", function (secondNumber){

            if (firstNumber + secondNumber < 10) {
                console.log(firstNumber + secondNumber)
            } if (firstNumber || secondNumber < 0) {
                console.log("Error")
            } else {
                console.log(firstNumber)
            }
            readline.close()
        })
    })
}
sumLimit()

// For this question, instead of checking a single digit number,
// find the digits of firstNumber and base it off of that.
// if firstNumber were 100, then  99 < firstNumber + secondNumber < 1000
// the sum should be the same number of digits as whatever the firstNumber is
